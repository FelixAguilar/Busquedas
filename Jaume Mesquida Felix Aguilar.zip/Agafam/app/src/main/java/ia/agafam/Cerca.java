package ia.agafam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class Cerca {

	private ArrayList<Node> llista;
	private Joc graella;

	Cerca(Joc graella)
	{
		this.graella = graella;
		llista = new ArrayList<Node>();
	}

	// Metodo utilizado A* realizado por Jaume Mesquida y Felix Aguilar.
	public Node calculaCasella(Punt inici) {

		// Obtiene la coordenada donde se encuentra la rana y genera un nodo con ella.
		Punt p = new Punt(inici.x, inici.y);
		Node n = new Node(p.x, p.y);

		// Calcula la distancia euclidia a la salida mas proxima de la ubicación actual.
		n.g = 0;
		n.h = graella.getEstimatedDistanceToGoal(p.x, p.y);

		// Crea la lista de nodos abiertos y cerrados.
		Queue<Node> abiertos = new PriorityQueue<Node>(graella.CASELLES_PER_COLUMNA * graella.CASELLES_PER_FILA, new Comparador());
		ArrayList cerrados = new ArrayList<Node>();

		// Mientras haya nodos que procesar y la casilla no se encuentre fuera del tablero.
		while (!cerrados.contains(n) && graella.casellaDinsGraella(p)) {

			// Revisa todas las casillas vecinas al nodo.
			for (Direccio d : Direccio.values()) {

				// Si no es la direccion central, entonces procede.
				if (d != Direccio.C) {

					// Obtiene las coordenadas de la casilla vecino y crea el nodo correspondiente.
					Punt q = d.coordenadesVeinat(p);
					Node m = new Node(q.x, q.y);

					// Si no esta dentro de la lista de cerrados entonces procede.
					if (!cerrados.contains(m)) {

						// Si no hay un obstaculo en la casilla entonces procede.
						if (!graella.hiHaObstacle(q)) {

							// Calcula la distancia real a la meta y la distancia euclidia a esta.
							m.g = n.g + 1;
							m.h = graella.getEstimatedDistanceToGoal(q.x, q.y);

							// Guarda el nodo de inicio del bucle como previo del nuevo nodo.
							m.setNodePrevi(n);

							// Añade el nuevo nodo a la lista de abiertos.
							abiertos.add(m);
						}
					}
				}
			}

			// Finalizado la revision de los vecinos el nodo se guarda en la lista de cerrados.
			cerrados.add(n);

			// Busca el siguiente nodo a explorar si no esta en la lista de cerrados.
			while (cerrados.contains(n) && !abiertos.isEmpty()){
				n = abiertos.poll();
				p.x = n.x;
				p.y = n.y;
			}
		}

		// Si el nodo esta fuera del tablero procede.
		if(!graella.casellaDinsGraella(p)) {

			// Crea  dos nuevos nodos y copia el nodo final en predecesor.
			Node aux = new Node();
			Node predecessor = new Node();
			predecessor.igual(n);

			// Mientras el nodo previo de predecessor sea diferente de null realiza el bucle.
			while (predecessor.nodePrevi != null) {

				// Copia predecessor en el auxiliar y copia el nodo previo al predecessor.
				aux.igual(predecessor);
				predecessor.igual(predecessor.nodePrevi);

				// Crea un punto con las coordenadas de aux y si no hay obstaculo lo añade a la solucion.
				Punt pt = new Punt(aux.getX(), aux.getY());
				if (!graella.hiHaObstacle(pt)) {
					graella.afegirNodeSolucio(pt); }
			}

			// Copia el nodo auxiliar en n y lo devuelve.
			n = aux;
			return n;
		}
		return null;
	}
}

// Clase para comparar las distancias entre dos nodos, utilizado para ordenarlos en la lista de abiertos.
class Comparador implements Comparator<Node>{
	public int compare(Node n1, Node n2) {
		if ((n1.g + n1.h) > (n2.g + n2.h) || ((n1.g + n1.h) == (n2.g + n2.h) && (n1.h < n2.h))) {

			// Si n1 es mayor en f o bien en n1 es menor en h.
			return 1;
		} else if((n1.g + n1.h) < (n2.g + n2.h) || ((n1.g + n1.h) == (n2.g + n2.h) && (n1.h > n2.h))){

			// Si n1 es menor en f o bien n1 es mayor en h.
			return -1;
		}
		return 0;
	}
}

