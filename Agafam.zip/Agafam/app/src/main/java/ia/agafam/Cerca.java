package ia.agafam;

import java.util.ArrayList;
import java.util.Collections;

public class Cerca {

	private ArrayList<Node> llista;
	private Joc graella;

	Cerca(Joc graella)
	{
		this.graella = graella;
		llista = new ArrayList<Node>();
	}

	public Node calculaCasella(Punt inici)
	{
		if (graella.noPucMoure(inici)){
			ArrayList abiertos = new ArrayList<Nodo>();
			ArrayList cerrados = new ArrayList<Nodo>();

			abiertos.

		}



		return nodo;



		// retorna el proper node on s'ha de moure o null si no hi ha cap possibilitat de moviment
		// inici és la casella inicial on està el bitxo

		//Node tmpNode;
		// Mira si hi ha pedra per on vull anar

		//if (graella.noPucMoure(inici)) return null;

		//Punt casellaPitjada = graella.casellaPitjada(); // Coordenades de la casella on
														// s'ha pitjat amb el dit
		//tmpNode = new Node(casellaPitjada.x, casellaPitjada.y);

		// Per mirar si una casella pertany a la graella: graella.casellaDinsGraella(Punt coordenades)

		// Exemple per omplir una llista amb tots els veinats
		// de la casella on hem pitjat

		//for (Direccio d: Direccio.values())   // per totes les direccions
		//{
			//if (d != Direccio.C) // ignora la meva posició (Central)
			//{
				//Punt p=d.coordenadesVeinat(casellaPitjada);	 // coordenades de la casella veinada
				//llista.add(new Node(p.x,p.y));
			//}
		//}

		// Exemple per posar totes les caselles veinades que no tenen pedra
		// com si fossin el camí de la solució

		//for (Node n:llista)
		//{
			// p = new Punt(n.getX(), n.getY());

			//if (!graella.hiHaObstacle(p))       // si no hi ha pedra
				//graella.afegirNodeSolucio(p);   // els nodes afegits es pintaran com a camí solució
		//}

		//System.out.println("Info:"+casellaPitjada.x+" "+casellaPitjada.y);
		//return tmpNode; // El node retornat és on es mourà el bitxo automàticament
		// Teòricament ha de tornar, la propera casello on s'ha de
		// moure segons s'ha calculat el camí !!!
	}

	public int h(Punt p){
		int x;
		int y;
		if (p.x > 4) {
			x = Math.abs(p.x - 8);
		} else {
			x = p.x;
		}
		if (p.y > 4) {
			y = Math.abs(p.y - 8);
		} else {
			y = p.x;
		}
		if (x < y) {
			return x;
		} else {
			return y;
		}
	}

}

